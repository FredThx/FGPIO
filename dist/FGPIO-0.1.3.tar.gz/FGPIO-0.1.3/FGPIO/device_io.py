#!/usr/bin/env python
# -*- coding:utf-8 -*

from pin_io import *

class device_io:
	""" Classe decrivant un device a connecter à un	rpiduino_io
			(soit rpi_io ou pcduino_io)
	"""
	def __init__():
		pass
	# pour l'instant aucun interet!!!