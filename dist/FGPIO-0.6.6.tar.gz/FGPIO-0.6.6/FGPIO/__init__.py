#!/usr/bin/env python

__version__='0.6.6'

